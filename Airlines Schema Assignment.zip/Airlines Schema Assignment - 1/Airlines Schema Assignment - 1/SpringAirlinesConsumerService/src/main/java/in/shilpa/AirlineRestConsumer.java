package in.shilpa;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("Producer-SERVICE")
public interface AirlineRestConsumer {

	@GetMapping("/passenger/all")
	public String getAllpassengers();

	@GetMapping("/flight/all")
	public String findAllFlights(@PathVariable String code);
	

	@GetMapping("/passenger/{id}")
	public String getpassengerbyId(@PathVariable Long id);
	
	@GetMapping("/flight/{id}")
	public Flight getflightbyId(@PathVariable Long id);
	
	@GetMapping("/book/{regid},{id}")
	public String bookFlight(@PathVariable Long regid , @PathVariable Long id);


}
