package in.shilpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.shilpa.model.Flight;

public interface FlightRepository extends JpaRepository <Flight , Long>{

}
