package in.shilpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.shilpa.Repository.RegistrationRepository;
import in.shilpa.model.Registration;
import in.shilpa.service.RegistrationService;

@Service
public class RegistrationServiceimpl implements RegistrationService {

	@Autowired
	private RegistrationRepository repo;
	
	@Override
	public Long savePassenger(Registration p) {
		p = repo.save(p);
		return p.getRegid();
	}

	

	@Override
	public List<Registration> getAllPassengers() {
		List l = (List) repo.findAll();
		return l;
	}



	@Override
	public Registration getPassengerById(Long id) {
		
		return repo.findById(id).get();
	}

	
}
